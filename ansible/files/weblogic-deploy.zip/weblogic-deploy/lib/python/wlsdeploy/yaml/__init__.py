"""
Package to handle translating between Yaml files and Python dictionaries.
"""
