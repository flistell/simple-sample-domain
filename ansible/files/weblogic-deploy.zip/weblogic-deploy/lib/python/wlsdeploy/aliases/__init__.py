"""
Copyright (c) 2017, 2018, Oracle and/or its affiliates. All rights reserved.
The Universal Permissive License (UPL), Version 1.0

This package provides the WLST knowledge base used by the rest of the code to understand how to perform
their work across WebLogic versions and WLST modes.
"""
